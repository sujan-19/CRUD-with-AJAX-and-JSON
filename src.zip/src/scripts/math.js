export const sum = (a, b) => a + b

export const sub = (a, b) => a - b